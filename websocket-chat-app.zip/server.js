
const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

const PORT = 3000;
const users = {}; // socket.id -> username

app.use(express.static("public"));

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("register", (username) => {
    users[socket.id] = username;
    socket.broadcast.emit("notification", `${username} joined the chat`);
  });

  socket.on("message", (msg) => {
    const sender = users[socket.id] || "Anonymous";
    io.emit("message", { sender, msg });
  });

  socket.on("private_message", ({ toSocketId, msg }) => {
    const sender = users[socket.id];
    io.to(toSocketId).emit("private_message", { sender, msg });
  });

  socket.on("disconnect", () => {
    const username = users[socket.id];
    delete users[socket.id];
    io.emit("notification", `${username} left the chat`);
  });
});

http.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
