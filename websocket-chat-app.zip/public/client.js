
const socket = io();

function register() {
  const username = document.getElementById("username").value;
  socket.emit("register", username);
}

function sendMessage() {
  const msg = document.getElementById("message").value;
  socket.emit("message", msg);
  document.getElementById("message").value = '';
}

socket.on("message", ({ sender, msg }) => {
  const li = document.createElement("li");
  li.textContent = `${sender}: ${msg}`;
  document.getElementById("messages").appendChild(li);
});

socket.on("notification", (msg) => {
  const li = document.createElement("li");
  li.style.color = "gray";
  li.textContent = msg;
  document.getElementById("messages").appendChild(li);
});

socket.on("private_message", ({ sender, msg }) => {
  alert(`Private message from ${sender}: ${msg}`);
});
