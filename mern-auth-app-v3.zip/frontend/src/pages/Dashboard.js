
import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    axios.get("/api/auth/dashboard", {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => setMsg(res.data))
      .catch(err => setMsg("Unauthorized"));
  }, []);

  return <h1>{msg}</h1>;
}
